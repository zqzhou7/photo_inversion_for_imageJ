# Load required package
if (!require("magick")) install.packages("magick", dependencies = TRUE)
library(magick)

# Create a new folder for inverted images (if it doesn't exist)
output_folder <- "inverted"
if (!dir.exists(output_folder)) {
  dir.create(output_folder)
}

# List all .jpg files in the current directory
jpg_files <- list.files(pattern = "\\.jpg$", ignore.case = TRUE)

# Loop through and process each image
for (file in jpg_files) {
  img <- image_read(file)
  img <- image_contrast(img, sharpen = 1)                # Sharpen contrast
  img_hsl <- image_convert(img, colorspace = "HSL")      # Convert to HSL
  img_channel <- image_channel(img_hsl, "lightness")     # Extract lightness
  img_inverted <- image_negate(img_channel)              # Invert lightness
  output_path <- file.path(output_folder, file)
  image_write(img_inverted, path = output_path, format = "jpg")
  message("Lightness-inverted: ", file)
}

